
                        autoScrollTimer.Elapsed += AutoScrollTimer_Elapsed;

